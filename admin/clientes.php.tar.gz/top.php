<link href="../css/estilos.css" rel="stylesheet" type="text/css" />
<table width="185" border="0" cellpadding="0" cellspacing="0">
  <tr>
    <td height="5"><img src="logo.jpg" /></td>
  </tr>
  <tr>
    <td height="5"><? include("indice.php")?></td>
  </tr>
</table>



